export const SERVER_API_URL ="/api"

// export const SERVER_API_URL="http://3.23.168.79:5000/api"